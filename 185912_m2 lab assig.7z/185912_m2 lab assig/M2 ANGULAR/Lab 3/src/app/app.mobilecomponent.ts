import { Component } from '@angular/core';
import {Mobile} from './Mobile';
import {Camera} from './camera';
import { NgForm } from '../../node_modules/@angular/forms';
import { Prodavail } from './prodavail';
@Component({
    selector:'mob-app',
    templateUrl:'./app.mobile.html'

})

export class ProductComponent{
    options= [
      {name:"BigBazar",value:1,checked:false},
        {name:"DMart",value:2,checked:false},
        {name:"Reliance",value:3,checked:false},
        {name:"BigMart",value:4,checked:false}
]

    productData:Mobile={
            mobId:null,
            mobName:null,
            mobPrice:null,
            type:null,
            cam:null,
            cat:null,
            prodava:[],
            isValidFormSumitted:false
        }
        camArray:Camera[]=[
            {camTypeId:1,camTypeName:"Grocery"},
            {camTypeId:2,camTypeName:"Mobile"},
            {camTypeId:3,camTypeName:"Electronics"},
            {camTypeId:4,camTypeName:"Cloth"}

        ]
       // prodavail:Prodavail[]=[];
       
        productAdd(model:NgForm)
        {
            this.productData.isValidFormSumitted = false;
            if (model.invalid) {
            return;
            }
            this.productData.isValidFormSumitted = true; 
 


            //alert("dddd");
            console.log(`Product Id: ${this.productData.mobId}
            Product Name: ${this.productData.mobName} 
            Product Price: ${this.productData.mobPrice}
            Product Awailable Online: ${this.productData.type}
            `);
            for(let data of this.camArray){
            if(data.camTypeId == Number(this.productData.cam)) {
            this.productData.cam = data;
            console.log("Product Catagory: " + data.camTypeName);
             }
             }  
            for(let dataa of this.options){
               if(dataa.checked ){
    
    this.productData.prodava.push({prodTypeId:dataa.value,prodTypeName:dataa.name})
    console.log("Product Availability: " +dataa.name);
}
                
                 }
        }  
isCheckValid():boolean{
    let f=0;
    for (const m of this.options) {
    if(m.checked==true)
    {
    f=1;
    }
    }
    if(f==0)
    return false;
    else 
    return true;
    } 
    }





// Product Availability: ${this.productData.prodava}